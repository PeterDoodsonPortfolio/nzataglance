from django.shortcuts import render
from django.http import HttpResponse
from django.http import Http404
from django.shortcuts import get_object_or_404
import datetime
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.views import generic
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import Tour, Agent

def home(request):
     # Number of visits to this view, as counted in the session variable.
    num_visits=request.session.get('num_visits', 0)
    request.session['num_visits'] = num_visits+1

    return render(request, 'home.html', context={ 'num_visits': num_visits})

def tour_detail(request, id):
    try:
        tour = Tour.objects.get(id=id)
    except Tour.DoesNotExist:
        raise Http404('Tour not found')

    return render(request, 'tour_detail.html', {'tour': tour})

def agent_detail(request, id):
    try:
        agent = Agent.objects.get(id=id)
    except Agent.DoesNotExist:
        raise Http404('Tour not found')

    return render(request, 'agent_detail.html')



class tours_by_agent(LoginRequiredMixin, generic.ListView):

    model = Tour
    template_name ='home/tours_by_agent.html'
    paginate_by = 10

    def get_queryset(self):

       try:
           agent = Agent.objects.get(agent_user = self.request.user)
       except Agent.DoesNotExist:
           raise Http404('You are not an agent')
       return Tour.objects.filter(agent = agent)



class TourListView(generic.ListView):
    model = Tour
    paginate_by = 10

class AgentListView(generic.ListView):
    model = Agent
    paginate_by = 10


class TourDetailView(generic.DetailView):
    model = Tour

class AgentDetailView(generic.DetailView):
    model = Agent
